/**
 * 
 */
package com.visa.skillapp.client;


/**
 * @author Banu Prakash
 *
 * CLient code 
 */
public class EmployeeClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	}


}
