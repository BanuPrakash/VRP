/**
 * 
 */
package com.visa.skillapp.service;

import java.util.List;

import com.visa.skillapp.entity.Employee;

/**
 * @author Banu Prakash
 * 
 */
public interface EmployeeSkillService {

	List<Employee> getEmployees(String... args);
}
