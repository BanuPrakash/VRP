/**
 * 
 */
package com.visa.rental.entity;

/**
 * @author 
 * 
 * 
 * Vehicle entity class to represent business data
 *
 */
public class Vehicle {
	
	private String registrationNumber;
	
	private String model;
	
	private double rentPerDay;

	/**
	 * 
	 */
	public Vehicle() {
	}

	/**
	 * @param registrationNumber
	 * @param model
	 * @param rentPerDay
	 */
	public Vehicle(String registrationNumber, String model, double rentPerDay) {
		this.registrationNumber = registrationNumber;
		this.model = model;
		this.rentPerDay = rentPerDay;
	}

	/**
	 * @return the registrationNumber
	 */
	public String getRegistrationNumber() {
		return registrationNumber;
	}

	/**
	 * @param registrationNumber the registrationNumber to set
	 */
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the rentPerDay
	 */
	public double getRentPerDay() {
		return rentPerDay;
	}

	/**
	 * @param rentPerDay the rentPerDay to set
	 */
	public void setRentPerDay(double rentPerDay) {
		this.rentPerDay = rentPerDay;
	}
	
	
}
