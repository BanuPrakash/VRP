/**
 * 
 */
package com.visa.rental.entity;

import java.util.Date;

/**
 * @author
 * 
 *         Rental business entity class
 */
public class Rental {

	private Vehicle vehicle;
	
	private Date rentFromDate;
	
	private Date rentUntilDate;

	/**
	 * 
	 */
	public Rental() {
	}

	/**
	 * @param vehicle
	 * @param rentFromDate
	 * @param rentUntilDate
	 */
	public Rental(Vehicle vehicle, Date rentFromDate, Date rentUntilDate) {
		this.vehicle = vehicle;
		this.rentFromDate = rentFromDate;
		this.rentUntilDate = rentUntilDate;
	}

	/**
	 * @return the vehicle
	 */
	public Vehicle getVehicle() {
		return vehicle;
	}

	/**
	 * @param vehicle the vehicle to set
	 */
	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	/**
	 * @return the rentFromDate
	 */
	public Date getRentFromDate() {
		return rentFromDate;
	}

	/**
	 * @param rentFromDate the rentFromDate to set
	 */
	public void setRentFromDate(Date rentFromDate) {
		this.rentFromDate = rentFromDate;
	}

	/**
	 * @return the rentUntilDate
	 */
	public Date getRentUntilDate() {
		return rentUntilDate;
	}

	/**
	 * @param rentUntilDate the rentUntilDate to set
	 */
	public void setRentUntilDate(Date rentUntilDate) {
		this.rentUntilDate = rentUntilDate;
	}
	
	
}
