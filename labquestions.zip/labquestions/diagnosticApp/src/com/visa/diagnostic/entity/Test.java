package com.visa.diagnostic.entity;
/**
 * 
 * @author Banu Prakash
 * entity containing test name and cost of test 
 */
public class Test {
	private String testName;
	private double cost;
	/**
	 * 
	 */
	public Test() {
	}
	/**
	 * @param testName
	 * @param cost
	 */
	public Test(String testName, double cost) {
		this.testName = testName;
		this.cost = cost;
	}
	/**
	 * @return the testName
	 */
	public String getTestName() {
		return testName;
	}
	/**
	 * @param testName the testName to set
	 */
	public void setTestName(String testName) {
		this.testName = testName;
	}
	/**
	 * @return the cost
	 */
	public double getCost() {
		return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	
}
