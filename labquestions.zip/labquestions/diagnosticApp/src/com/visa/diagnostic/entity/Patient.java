/**
 * 
 */
package com.visa.diagnostic.entity;

import java.util.Date;

/**
 * @author Banu Prakash
 * 
 *         entity class to represent business data of Patient
 */
public class Patient {
	private String name;
	private String email;
	private String phone;
	private Date dateOfBirth;
	/**
	 * 
	 */
	public Patient() {
	}
	/**
	 * @param name
	 * @param email
	 * @param phone
	 * @param dateOfBirth
	 */
	public Patient(String name, String email, String phone, Date dateOfBirth) {
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return the dateOfBirth
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	
}
