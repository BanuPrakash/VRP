/**
 * 
 */
package com.visa.diagnostic.entity;

/**
 * @author Banu Prakash
 * 
 */
public class DiagnosticTest {
	/*
	 * add attributes and association as per requirement
	 */

}
