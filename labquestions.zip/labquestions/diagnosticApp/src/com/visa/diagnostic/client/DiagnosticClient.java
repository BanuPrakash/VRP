/**
 * 
 */
package com.visa.diagnostic.client;

import com.visa.diagnostic.util.KeyboardUtil;

/**
 * @author Banu Prakash
 * 
 *         client code for Diagnostic tests
 */
public class DiagnosticClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		while (true) {
			int choice = getChoices();
			switch (choice) {
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				System.exit(1);
			}
		}
	}

	/**
	 * Method to print options
	 * 
	 * @return selected choice
	 */
	private static int getChoices() {
		System.out.println("1.Add Patient Details");
		System.out.println("2.Add Diagnostic tests to be done for a Patient");
		System.out.println("3.Get Test details of a Patient");
		System.out.println("4.Exit");
		return KeyboardUtil.getInt("Enter choice[1/2/3/4]");
	}

}
