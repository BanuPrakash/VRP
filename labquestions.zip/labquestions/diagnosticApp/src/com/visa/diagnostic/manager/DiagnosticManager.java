/**
 * 
 */
package com.visa.diagnostic.manager;

import java.util.Date;

import com.visa.diagnostic.entity.DiagnosticTest;
import com.visa.diagnostic.entity.Patient;
import com.visa.diagnostic.entity.Test;

/**
 * @author Banu Prakash
 * 
 *         Diagnostic manager class
 */
public class DiagnosticManager {

	/*
	 * list of available tests
	 */
	private static Test[] tests = new Test[4];

	/*
	 * list of patients
	 */
	private static Patient[] patients = new Patient[4];
	/*
	 * list of reports
	 */
	private static DiagnosticTest[] reports = new DiagnosticTest[10];

	static {
		/*
		 * add tests
		 */
		tests[0] = new Test("Lipid Profile", 500.00);
		tests[1] = new Test("ECG", 1350.00);
		tests[2] = new Test("HBA1c", 1050.00);
		tests[3] = new Test("Blood Group", 100.00);
	}

	/**
	 * 
	 * @param patient
	 *            patient to be added
	 */
	public static void addPatient(Patient patient) {
		/*
		 * complete the code to store the patient in patients[]
		 */
	}

	/**
	 * 
	 * @param patient
	 *            for whom test is done
	 * @param test
	 *            selected test for diagnostic
	 */
	public static void addDiagnositicTest(Patient patient, Test test) {
		/*
		 * complete the code to store the information in DiagnosticTest[]
		 * reports Test Date should be system Date
		 */
	}

	/**
	 * 
	 * @param patient
	 *            whose report has to be returned
	 * @param testDate
	 *            date on which test was done
	 * @return Report
	 */
	public static DiagnosticTest[] getDiagnosticTests(Patient patient,
			Date testDate) {
		/*
		 * return all the Diagnostic tests opted by the patient on a specific
		 * date
		 */
		return null;
	}

	/**
	 * 
	 * @param email
	 *            email of patient
	 * @return patient with emailId email
	 */
	public static Patient getPatientByEmail(String email) {
		/*
		 * return a patient whose email is passed as argument
		 */
		return null;
	}

	/**
	 * 
	 * @param phone
	 *            phone of patient
	 * @return patient with phoneNo phone
	 */
	public static Patient getPatientByPhone(String phone) {
		/*
		 * return a patient whose phone is passed as argument
		 */
		return null;
	}

	/**
	 * 
	 * @return all available tests
	 */
	public Test[] getTests() {
		return tests;
	}

	/**
	 * 
	 * @param testName
	 *            name of test
	 * @return Test Object matching testName
	 */
	public static Test getTest(String testName) {
		/*
		 * return a Test object whose test name is passed as argument
		 */
		return null;
	}
}
